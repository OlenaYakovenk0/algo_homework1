#pragma once
#include <string>
using namespace std;


struct Student {
    string m_name, m_surname, m_email, m_group, m_phone_number;
    int m_birth_year, m_birth_month, m_birth_day;
    float m_rating;
};
